package com.customtag.AddressTag;
import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class AddressTag extends TagSupport{
	
	public int doStartTag() throws JspException {
		
		JspWriter out=pageContext.getOut();
		
		try {
			out.println("Block C Divyasree Technopolis <br/>");
			out.println("Survey No: 123 &132/2, Yemlur Post<br/>");
			out.println("Yemlur, Off Old Airport Road<br/>");
			out.println("Karnataka<br/>");
			out.println("560037<br/>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return super.doStartTag();
	}

}

