

import java.util.Scanner;

abstract class Arithmetic {
	 
int num1;
int num2;
int num3;
abstract double calculate(double num1, double num2);
public void read() {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter you two numbers");
	int num1 = scanner.nextInt();
	int num2 = scanner.nextInt();

}

public static void main(String[] args) {
	

	System.out.println("Enter your Choice!");
	System.out.println("1.Add");
	System.out.println("2.Sub");
	System.out.println("3.Mul");
	System.out.println("4.Div");
	
Object[] choice = {new Addition(), new Subtraction(), new Multiplication(), new Divide()};
System.out.println("Enter your choice:\n1. Add\n2. Sub\n3. Multiply\n4. Divide\n5. Exit");
		int input;
		Scanner sc = new Scanner(System.in);
		input = sc.nextInt();
		
		System.out.println("Enter two numbers: ");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		double result = ((Arithmetic)choice[input-1]).calculate(num1, num2);
		System.out.println(result);
		sc.close();

}}
	
	


 class Addition extends Arithmetic {

	@Override
	double calculate(double num1, double num2) {
	double sum = (num1+num2);
		return sum;
	}
		
	}
	
 class Subtraction extends Arithmetic {

	@Override
	double calculate(double num1, double num2) {
		double diff = (num1-num2);
			return diff;
		
	}
	
}
 class Multiplication extends Arithmetic {

	@Override
	double calculate(double num1, double num2) {
		double mul = (num1*num2);
		return mul;
	}
		
	}
	
 class Divide extends Arithmetic {

	@Override
	double calculate(double num1, double num2) {
		double div = num1/num2;
		return div;
	}
	
	


	
}


	


