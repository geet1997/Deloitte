public class EmployeeBo {

	public void calincomeTax(EmployeeVo e) {
		
		double a=e.getAnnualincome();
		
		if(a<2000) {
			e.setIncometax(0);
		}
		else if(a<5000)
		{
			e.setIncometax(.25*a);
		}
		else
		{
			e.setIncometax(0.5*a);
		}
		
	}
}
