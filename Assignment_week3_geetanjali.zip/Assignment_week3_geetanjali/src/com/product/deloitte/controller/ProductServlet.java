package com.product.deloitte.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.dao.impl.ProductDAOImpl;
import com.cms.deloitte.model.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId = Integer.parseInt(request.getParameter("productId"));
		String productName = request.getParameter("productName");
		int qoh = Integer.parseInt(request.getParameter("qoh"));
		int price = Integer.parseInt(request.getParameter("price"));
			response.getWriter().print("<h1> Product Id </h1>");
			
				response.getWriter().print("999service");
				response.getWriter().print("<br/>"+productId);
				response.getWriter().print("<h2>Product Name</h2>");
				response.getWriter().print("<br/>"+ productName);
				response.getWriter().print("<h3>Product Quantity</h3>");
				response.getWriter().print("<br/>"+qoh);
				response.getWriter().print("<h4>Price</h4>");
				response.getWriter().print("<br/>"+price);
				
				Product product = new Product(productId, productName, qoh, price);
				
				ProductDAO productDAO = new ProductDAOImpl();
				
				productDAO.saveProduct(product);
				
				
					response.getWriter().println(productName + "saved successfully");
					//RequestDispatcher dispatcher=
							//request.getRequestDispatcher("DisplayServlet");
				//dispatcher.include(request, response);
	}

}
