package com.cms.deloitte.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cms.deloitte.dao.ProductDAO;
import com.cms.deloitte.model.Product;

public class ProductDAOImpl implements ProductDAO {
	Configuration configuration=null;
	SessionFactory  factory=null;
	
	public ProductDAOImpl() {
		configuration = new Configuration().configure();
		factory = configuration.buildSessionFactory();
	}

	@Override
	public boolean saveProduct(Product product) {
Session session= factory.openSession();
		
		Transaction transaction = session.beginTransaction();
		session.save(product);
		
		transaction.commit();
		
		return false;
	}

	@Override
	public List<Product> listProduct() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Product");
		
		return query.list();
	}

}
