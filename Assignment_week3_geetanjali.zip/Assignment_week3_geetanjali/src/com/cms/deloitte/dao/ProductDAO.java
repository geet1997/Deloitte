package com.cms.deloitte.dao;

import java.util.List;

import com.cms.deloitte.model.Product;

public interface ProductDAO {

	public boolean saveProduct(Product product);
	public List<Product> listProduct();
	
}
