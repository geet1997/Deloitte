package com;

import org.springframework.core.io.ClassPathResource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.Resource;
import com.config.*;
/**
 * Hello world!
 *
 */
public class AppSpring 
{
    public static void main( String[] args )
    {
    	/*Resource resource = new ClassPathResource("beans.xml");*/
    	AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	/*BeanFactory factory = new XmlBeanFactory(resource);*/
  
        Customer customer = context.getBean(Customer.class);
        Customer customer1 = context.getBean(Customer.class);
        Customer customer2 = context.getBean(Customer.class);
        customer.setCustomerId(1222);
        customer.setCustomerAddress("Kerala");
        customer.setCustomerName("Anu");
        customer.setBillAmount(1937);
       
       ContactDetails contactDetails = context.getBean(ContactDetails.class);
       contactDetails.setMailId("Geet@gmail.com");
       contactDetails.setMobileNumber("184728");
       customer.setContactDetails(contactDetails);
       System.out.println(contactDetails);
       System.out.println(customer);
       System.out.println(customer1);
       System.out.println(customer2);
       context.registerShutdownHook();
       
    }
}
